package org.firstinspires.ftc.teamcode.PathGen.core;

import java.util.ArrayList;
import java.util.List;

/**
 * The PURE path-planning brain -- plain Java + Math only, NO Pedro/Android. The robot's PathPlanner
 * runs this then converts the result to a Pedro path; the desktop visualizer runs the same class.
 *
 *  - plan(waypoints): forward pass, the FRONT leads through every point (for a front intake).
 *  - planReturn(from, to, incomingHeading): a non-intake leg (e.g. returning to a fixed scoring
 *    spot) that automatically picks FORWARD or REVERSE -- whichever is faster -- so a straight
 *    there-and-back reverses (no 180 spin) while a long loop around an obstacle keeps driving
 *    forward. Endpoints that land inside an obstacle are nudged to the nearest clear spot; because
 *    clearance is a bounding circle, "clear" means clear at ANY heading.
 *  - never throws: always returns a GeoResult.
 */
public class PlanEngine {

    public double Vx = 76;              // forward/reverse speed in/s (fast longitudinal axis)
    public double Vy = 52;             // strafe speed in/s (slow lateral axis)
    public double catmullTension = 6.0;
    public double turnRate = 4.0;      // rad/s, rough in-place turn rate for the forward-vs-reverse cost

    /** set by planReturn: true if the last return leg was chosen to be driven in reverse. */
    public boolean lastReturnReversed = false;

    private final Field field;

    public PlanEngine(Field field) { this.field = field; }

    /** Plan through waypoints (each {x, y}), start first and end last, all forward. Never throws. */
    public GeoResult plan(List<double[]> waypoints) {
        try {
            List<String> notes = new ArrayList<String>();
            if (waypoints == null || waypoints.size() < 2)
                return GeoResult.failed("need at least a start and an end point");

            List<double[]> pts = new ArrayList<double[]>();
            for (int i = 0; i < waypoints.size(); i++) {
                double[] w = waypoints.get(i);
                if (field.blocked(w[0], w[1])) {
                    double[] freed = nudgeOut(w[0], w[1]);
                    if (freed == null)
                        return GeoResult.failed("waypoint " + i + " " + fmt(w) + " is stuck inside an obstacle");
                    notes.add("waypoint " + i + " was inside an obstacle, moved " + fmt(w) + " -> " + fmt(freed));
                    pts.add(freed);
                } else {
                    pts.add(w);
                }
            }

            List<double[]> route = new ArrayList<double[]>();
            route.add(pts.get(0));
            for (int i = 0; i < pts.size() - 1; i++) {
                double[] a = pts.get(i), b = pts.get(i + 1);
                List<double[]> leg;
                if (field.isSegmentClear(a[0], a[1], b[0], b[1])) {
                    leg = new ArrayList<double[]>(); leg.add(a); leg.add(b);
                } else {
                    leg = routeAround(a, b);
                    if (leg == null)
                        return GeoResult.failed("no clear route from waypoint " + i + " to " + (i + 1));
                    notes.add("routed around an obstacle between waypoint " + i + " and " + (i + 1));
                }
                for (int k = 1; k < leg.size(); k++) route.add(leg.get(k));
            }

            double[] head = tangentHeadings(route);
            List<Seg> segs = buildSegs(route, head);
            return notes.isEmpty() ? GeoResult.ok(segs, route) : GeoResult.adjusted(segs, route, notes);
        } catch (Exception e) {
            return GeoResult.failed("planner error: " + e.getMessage());
        }
    }

    /**
     * Plan ONE non-intake leg from `from` to `to` that may be driven forward OR in reverse, choosing
     * whichever is faster. `incomingHeading` is the heading the robot already has (e.g. the direction
     * it faced arriving at the last ball) -- reversing holds that heading and skips the turn.
     */
    public GeoResult planReturn(double[] from, double[] to, double incomingHeading) {
        try {
            lastReturnReversed = false;
            if (from == null || to == null) return GeoResult.failed("null endpoint on return leg");

            List<String> notes = new ArrayList<String>();
            // nudge endpoints out of obstacles (works for all headings -- clearance is a circle)
            if (field.blocked(from[0], from[1])) {
                double[] f = nudgeOut(from[0], from[1]);
                if (f == null) return GeoResult.failed("return start stuck inside an obstacle");
                notes.add("return start moved out of an obstacle " + fmt(from) + " -> " + fmt(f));
                from = f;
            }
            if (field.blocked(to[0], to[1])) {
                double[] t = nudgeOut(to[0], to[1]);
                if (t == null) return GeoResult.failed("return target stuck inside an obstacle");
                notes.add("return target moved out of an obstacle " + fmt(to) + " -> " + fmt(t));
                to = t;
            }

            List<double[]> route;
            if (field.isSegmentClear(from[0], from[1], to[0], to[1])) {
                route = new ArrayList<double[]>(); route.add(from); route.add(to);
            } else {
                route = routeAround(from, to);
                if (route == null) return GeoResult.failed("no clear route on the return leg");
                notes.add("return routed around an obstacle");
            }

            // --- cost of FORWARD: turn to face the path, then drive the fast axis the whole way ---
            double firstTangent = Math.atan2(route.get(1)[1] - route.get(0)[1],
                                             route.get(1)[0] - route.get(0)[0]);
            double turn = Math.abs(wrap(firstTangent - incomingHeading));
            double len = polylineLength(route);
            double fwdCost = turn / turnRate + len / Vx;

            // --- cost of REVERSE: hold incomingHeading; speed drops where travel isn't along that axis ---
            double revCost = 0;
            for (int i = 0; i < route.size() - 1; i++) {
                double dx = route.get(i + 1)[0] - route.get(i)[0];
                double dy = route.get(i + 1)[1] - route.get(i)[1];
                double seg = Math.hypot(dx, dy);
                double theta = axisAngle(Math.atan2(dy, dx) - incomingHeading); // 0=along axis, pi/2=strafe
                revCost += seg / effSpeed(theta);
            }

            boolean reverse = revCost < fwdCost;
            lastReturnReversed = reverse;
            notes.add(reverse
                    ? "return REVERSED (est " + t1(revCost) + "s vs forward " + t1(fwdCost) + "s)"
                    : "return FORWARD (est " + t1(fwdCost) + "s vs reverse " + t1(revCost) + "s)");

            double[] head = new double[route.size()];
            if (reverse) {
                for (int i = 0; i < route.size(); i++) head[i] = incomingHeading;   // hold heading -> reverse
            } else {
                head = tangentHeadings(route);                                        // face travel -> forward
            }

            List<Seg> segs = buildSegs(route, head);
            return GeoResult.adjusted(segs, route, notes);   // note always explains the choice
        } catch (Exception e) {
            return GeoResult.failed("return planner error: " + e.getMessage());
        }
    }

    /**
     * Plan ONE continuous path through all waypoints (each {x,y}), start first and END last. Every
     * point except the last is treated as an INTAKE point (front leads through it, forward). The
     * LAST leg (into the end point) auto-picks forward vs reverse -- whichever is faster -- just like
     * planReturn, but it's all one path so the robot flows through the balls without stopping.
     * lastReturnReversed is set to the choice. Never throws.
     */
    public GeoResult planWithReturn(List<double[]> waypoints) {
        try {
            lastReturnReversed = false;
            List<String> notes = new ArrayList<String>();
            if (waypoints == null || waypoints.size() < 2)
                return GeoResult.failed("need at least a start and an end point");

            // sanitize every waypoint (nudge out of obstacles; valid at any heading)
            List<double[]> pts = new ArrayList<double[]>();
            for (int i = 0; i < waypoints.size(); i++) {
                double[] w = waypoints.get(i);
                if (field.blocked(w[0], w[1])) {
                    double[] freed = nudgeOut(w[0], w[1]);
                    if (freed == null)
                        return GeoResult.failed("waypoint " + i + " " + fmt(w) + " is stuck inside an obstacle");
                    notes.add("waypoint " + i + " moved out of an obstacle " + fmt(w) + " -> " + fmt(freed));
                    pts.add(freed);
                } else {
                    pts.add(w);
                }
            }

            // route each consecutive pair into one polyline, remembering where the final leg starts
            List<double[]> route = new ArrayList<double[]>();
            route.add(pts.get(0));
            int finalLegStart = 0;
            for (int i = 0; i < pts.size() - 1; i++) {
                if (i == pts.size() - 2) finalLegStart = route.size() - 1;   // index of the last intake point
                double[] a = pts.get(i), b = pts.get(i + 1);
                List<double[]> leg;
                if (field.isSegmentClear(a[0], a[1], b[0], b[1])) {
                    leg = new ArrayList<double[]>(); leg.add(a); leg.add(b);
                } else {
                    leg = routeAround(a, b);
                    if (leg == null) return GeoResult.failed("no clear route from waypoint " + i + " to " + (i + 1));
                    notes.add("routed around an obstacle between waypoint " + i + " and " + (i + 1));
                }
                for (int k = 1; k < leg.size(); k++) route.add(leg.get(k));
            }

            int n = route.size();
            double[] head = tangentHeadings(route);   // start everything forward (front leads)

            // heading the robot HAS arriving at the last intake point (to hold if we reverse)
            double hHold = (finalLegStart > 0)
                    ? Math.atan2(route.get(finalLegStart)[1] - route.get(finalLegStart - 1)[1],
                                 route.get(finalLegStart)[0] - route.get(finalLegStart - 1)[0])
                    : head[0];

            // cost of the final leg forward vs reverse
            double firstTangent = Math.atan2(route.get(finalLegStart + 1)[1] - route.get(finalLegStart)[1],
                                             route.get(finalLegStart + 1)[0] - route.get(finalLegStart)[0]);
            double turn = Math.abs(wrap(firstTangent - hHold));
            double len = 0, revCost = 0;
            for (int i = finalLegStart; i < n - 1; i++) {
                double dx = route.get(i + 1)[0] - route.get(i)[0];
                double dy = route.get(i + 1)[1] - route.get(i)[1];
                double s = Math.hypot(dx, dy);
                len += s;
                revCost += s / effSpeed(axisAngle(Math.atan2(dy, dx) - hHold));
            }
            double fwdCost = turn / turnRate + len / Vx;

            boolean reverse = revCost < fwdCost;
            lastReturnReversed = reverse;
            notes.add(reverse
                    ? "return REVERSED (est " + t1(revCost) + "s vs forward " + t1(fwdCost) + "s)"
                    : "return FORWARD (est " + t1(fwdCost) + "s vs reverse " + t1(revCost) + "s)");

            if (reverse) for (int i = finalLegStart; i < n; i++) head[i] = hHold;   // hold heading -> reverse home

            List<Seg> segs = buildSegs(route, head);
            return notes.isEmpty() ? GeoResult.ok(segs, route) : GeoResult.adjusted(segs, route, notes);
        } catch (Exception e) {
            return GeoResult.failed("planWithReturn error: " + e.getMessage());
        }
    }

    // ---- shortest route around obstacles: visibility graph + Dijkstra ----
    private List<double[]> routeAround(double[] start, double[] goal) {
        List<double[]> nodes = new ArrayList<double[]>();
        nodes.add(start);
        nodes.add(goal);
        nodes.addAll(field.navPoints());

        int n = nodes.size();
        double[] dist = new double[n];
        int[] prev = new int[n];
        boolean[] done = new boolean[n];
        for (int i = 0; i < n; i++) { dist[i] = Double.MAX_VALUE; prev[i] = -1; }
        dist[0] = 0;

        for (int it = 0; it < n; it++) {
            int u = -1; double best = Double.MAX_VALUE;
            for (int i = 0; i < n; i++) if (!done[i] && dist[i] < best) { best = dist[i]; u = i; }
            if (u == -1) break;
            done[u] = true;
            if (u == 1) break;
            double[] a = nodes.get(u);
            for (int v = 0; v < n; v++) {
                if (done[v]) continue;
                double[] b = nodes.get(v);
                if (!field.isSegmentClear(a[0], a[1], b[0], b[1])) continue;
                double d = dist[u] + Math.hypot(b[0] - a[0], b[1] - a[1]) / Vx;
                if (d < dist[v]) { dist[v] = d; prev[v] = u; }
            }
        }
        if (prev[1] == -1) return null;
        List<double[]> path = new ArrayList<double[]>();
        for (int at = 1; at != -1; at = prev[at]) path.add(0, nodes.get(at));
        return path;
    }

    private double[] nudgeOut(double x, double y) {
        for (double rad = 2; rad <= 48; rad += 2) {
            for (int a = 0; a < 16; a++) {
                double ang = 2 * Math.PI * a / 16;
                double nx = x + rad * Math.cos(ang), ny = y + rad * Math.sin(ang);
                if (!field.blocked(nx, ny)) return new double[]{ nx, ny };
            }
        }
        return null;
    }

    /** each point faces the next; last keeps the arrival heading (front leads = forward driving). */
    private double[] tangentHeadings(List<double[]> route) {
        int n = route.size();
        double[] h = new double[n];
        for (int i = 0; i < n; i++) {
            if (i < n - 1) {
                double[] p = route.get(i), nx = route.get(i + 1);
                h[i] = Math.atan2(nx[1] - p[1], nx[0] - p[0]);
            } else {
                h[i] = h[i - 1];
            }
        }
        return h;
    }

    /** build smoothed segments (cubic where it stays clear, straight otherwise) with given headings. */
    private List<Seg> buildSegs(List<double[]> route, double[] head) {
        List<Seg> segs = new ArrayList<Seg>();
        int n = route.size();
        for (int i = 0; i < n - 1; i++) {
            double[] p1 = route.get(i), p2 = route.get(i + 1);
            double[] p0 = route.get(Math.max(i - 1, 0));
            double[] p3 = route.get(Math.min(i + 2, n - 1));
            double[] cp = clearControlPoints(p0, p1, p2, p3);
            if (cp != null)
                segs.add(Seg.curved(p1[0], p1[1], head[i], p2[0], p2[1], head[i + 1],
                                    cp[0], cp[1], cp[2], cp[3]));
            else
                segs.add(Seg.straight(p1[0], p1[1], head[i], p2[0], p2[1], head[i + 1]));
        }
        return segs;
    }

    private double[] clearControlPoints(double[] p0, double[] p1, double[] p2, double[] p3) {
        double[] tensions = { catmullTension, 10, 18, 30, 60 };
        for (double k : tensions) {
            double c1x = p1[0] + (p2[0] - p0[0]) / k, c1y = p1[1] + (p2[1] - p0[1]) / k;
            double c2x = p2[0] - (p3[0] - p1[0]) / k, c2y = p2[1] - (p3[1] - p1[1]) / k;
            if (curveIsClear(p1[0], p1[1], c1x, c1y, c2x, c2y, p2[0], p2[1]))
                return new double[]{ c1x, c1y, c2x, c2y };
        }
        return null;
    }

    private boolean curveIsClear(double x0, double y0, double x1, double y1,
                                 double x2, double y2, double x3, double y3) {
        int samples = 20;
        for (int i = 0; i <= samples; i++) {
            double t = i / (double) samples, u = 1 - t;
            double x = u*u*u*x0 + 3*u*u*t*x1 + 3*u*t*t*x2 + t*t*t*x3;
            double y = u*u*u*y0 + 3*u*u*t*y1 + 3*u*t*t*y2 + t*t*t*y3;
            if (field.blocked(x, y)) return false;
        }
        return true;
    }

    // ---- small math helpers ----

    /** elliptical speed limit: full Vx along the robot's axis, down to Vy at 90deg (strafe). */
    private double effSpeed(double theta) {
        double c = Math.cos(theta) / Vx, s = Math.sin(theta) / Vy;
        return 1.0 / Math.sqrt(c * c + s * s);
    }

    /** reduce an angle to [0, pi/2]: forward and reverse along the axis are equally fast. */
    private static double axisAngle(double a) {
        double t = Math.abs(wrap(a));
        if (t > Math.PI / 2) t = Math.PI - t;
        return t;
    }

    private static double wrap(double a) {
        while (a >  Math.PI) a -= 2 * Math.PI;
        while (a < -Math.PI) a += 2 * Math.PI;
        return a;
    }

    private static double polylineLength(List<double[]> r) {
        double s = 0;
        for (int i = 0; i < r.size() - 1; i++)
            s += Math.hypot(r.get(i + 1)[0] - r.get(i)[0], r.get(i + 1)[1] - r.get(i)[1]);
        return s;
    }

    private static String fmt(double[] p) { return String.format("(%.1f, %.1f)", p[0], p[1]); }
    private static String t1(double s) { return String.format("%.1f", s); }
}
