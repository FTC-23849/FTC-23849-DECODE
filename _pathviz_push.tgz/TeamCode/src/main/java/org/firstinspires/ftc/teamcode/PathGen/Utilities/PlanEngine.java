package org.firstinspires.ftc.teamcode.PathGen.Utilities;

import java.util.ArrayList;
import java.util.List;

/**
 * The PURE path-planning brain. Everything that decides the SHAPE of the path lives here and
 * uses only plain Java + Math -- NO Pedro, NO Android. Because of that:
 *   - the robot's PathPlanner runs this, then just converts the output into a Pedro PathChain, and
 *   - the desktop visualizer runs this exact same class to draw what the robot will do.
 * There is no second copy of the logic anywhere, so the picture can't lie.
 *
 * What it does (same goals as before):
 *   - routes the SHORTEST forward-drivable path around inflated obstacles (visibility graph + Dijkstra)
 *   - gives every point a tangent heading so the FRONT leads through it (for a front intake)
 *   - smooths corners as much as stays clear (tighten-until-clear), straight only as a last resort
 *   - never throws: always returns a GeoResult
 */
public class PlanEngine {

    public double Vx = 76;              // forward speed in/s (fast axis) -- used to weight the route
    public double Vy = 52;              // strafe speed in/s (slow axis) -- kept for reference
    public double catmullTension = 6.0; // starting smoothing tension (higher = tighter)

    private final Field field;

    public PlanEngine(Field field) { this.field = field; }

    /** Plan through waypoints (each {x, y}), start first and end last. Never throws. */
    public GeoResult plan(List<double[]> waypoints) {
        try {
            List<String> notes = new ArrayList<String>();
            if (waypoints == null || waypoints.size() < 2)
                return GeoResult.failed("need at least a start and an end point");

            // 1) sanitize: nudge any waypoint inside an obstacle out to the nearest free spot
            List<double[]> pts = new ArrayList<double[]>();
            for (int i = 0; i < waypoints.size(); i++) {
                double[] w = waypoints.get(i);
                if (field.blocked(w[0], w[1])) {
                    double[] freed = nudgeOut(w[0], w[1]);
                    if (freed == null)
                        return GeoResult.failed("waypoint " + i + " " + fmt(w) + " is stuck inside an obstacle");
                    notes.add("waypoint " + i + " was inside an obstacle, moved " + fmt(w) + " -> " + fmt(freed));
                    pts.add(freed);
                } else {
                    pts.add(w);
                }
            }

            // 2) route each consecutive pair around obstacles into one polyline of points
            List<double[]> route = new ArrayList<double[]>();
            route.add(pts.get(0));
            for (int i = 0; i < pts.size() - 1; i++) {
                double[] a = pts.get(i), b = pts.get(i + 1);
                List<double[]> leg;
                if (field.isSegmentClear(a[0], a[1], b[0], b[1])) {
                    leg = new ArrayList<double[]>(); leg.add(a); leg.add(b);
                } else {
                    leg = routeAround(a, b);
                    if (leg == null)
                        return GeoResult.failed("no clear route from waypoint " + i + " to " + (i + 1));
                    notes.add("routed around an obstacle between waypoint " + i + " and " + (i + 1));
                }
                for (int k = 1; k < leg.size(); k++) route.add(leg.get(k));
            }

            // 3) tangent headings so the FRONT leads through every point (intake)
            double[] head = headings(route);

            // 4) segments: smoothest curve that stays clear, straight only if none fits
            List<Seg> segs = new ArrayList<Seg>();
            int n = route.size();
            for (int i = 0; i < n - 1; i++) {
                double[] p1 = route.get(i), p2 = route.get(i + 1);
                double[] p0 = route.get(Math.max(i - 1, 0));
                double[] p3 = route.get(Math.min(i + 2, n - 1));
                double[] cp = clearControlPoints(p0, p1, p2, p3);   // tightens until clear, or null
                if (cp != null)
                    segs.add(Seg.curved(p1[0], p1[1], head[i], p2[0], p2[1], head[i + 1],
                                        cp[0], cp[1], cp[2], cp[3]));
                else
                    segs.add(Seg.straight(p1[0], p1[1], head[i], p2[0], p2[1], head[i + 1]));
            }

            return notes.isEmpty() ? GeoResult.ok(segs, route) : GeoResult.adjusted(segs, route, notes);

        } catch (Exception e) {
            return GeoResult.failed("planner error: " + e.getMessage());   // never crash auto
        }
    }

    // ---- shortest route around obstacles: visibility graph + Dijkstra ----
    private List<double[]> routeAround(double[] start, double[] goal) {
        List<double[]> nodes = new ArrayList<double[]>();
        nodes.add(start);                    // 0
        nodes.add(goal);                     // 1
        nodes.addAll(field.navPoints());     // 2..n-1

        int n = nodes.size();
        double[] dist = new double[n];
        int[] prev = new int[n];
        boolean[] done = new boolean[n];
        for (int i = 0; i < n; i++) { dist[i] = Double.MAX_VALUE; prev[i] = -1; }
        dist[0] = 0;

        for (int it = 0; it < n; it++) {
            int u = -1; double best = Double.MAX_VALUE;
            for (int i = 0; i < n; i++) if (!done[i] && dist[i] < best) { best = dist[i]; u = i; }
            if (u == -1) break;
            done[u] = true;
            if (u == 1) break;
            double[] a = nodes.get(u);
            for (int v = 0; v < n; v++) {
                if (done[v]) continue;
                double[] b = nodes.get(v);
                if (!field.isSegmentClear(a[0], a[1], b[0], b[1])) continue;
                double d = dist[u] + Math.hypot(b[0] - a[0], b[1] - a[1]) / Vx;   // travel time (forward)
                if (d < dist[v]) { dist[v] = d; prev[v] = u; }
            }
        }
        if (prev[1] == -1) return null;
        List<double[]> path = new ArrayList<double[]>();
        for (int at = 1; at != -1; at = prev[at]) path.add(0, nodes.get(at));
        return path;
    }

    // ---- move a blocked point out to the nearest free spot (spiral search) ----
    private double[] nudgeOut(double x, double y) {
        for (double rad = 2; rad <= 48; rad += 2) {
            for (int a = 0; a < 16; a++) {
                double ang = 2 * Math.PI * a / 16;
                double nx = x + rad * Math.cos(ang), ny = y + rad * Math.sin(ang);
                if (!field.blocked(nx, ny)) return new double[]{ nx, ny };
            }
        }
        return null;
    }

    // ---- each point faces the next; last point keeps the arrival heading ----
    private double[] headings(List<double[]> route) {
        int n = route.size();
        double[] h = new double[n];
        for (int i = 0; i < n; i++) {
            if (i < n - 1) {
                double[] p = route.get(i), nx = route.get(i + 1);
                h[i] = Math.atan2(nx[1] - p[1], nx[0] - p[0]);
            } else {
                h[i] = h[i - 1];
            }
        }
        return h;
    }

    // try progressively tighter curves; return {c1x,c1y,c2x,c2y} of the first that stays clear, else null
    private double[] clearControlPoints(double[] p0, double[] p1, double[] p2, double[] p3) {
        double[] tensions = { catmullTension, 10, 18, 30, 60 };
        for (double k : tensions) {
            double c1x = p1[0] + (p2[0] - p0[0]) / k, c1y = p1[1] + (p2[1] - p0[1]) / k;
            double c2x = p2[0] - (p3[0] - p1[0]) / k, c2y = p2[1] - (p3[1] - p1[1]) / k;
            if (curveIsClear(p1[0], p1[1], c1x, c1y, c2x, c2y, p2[0], p2[1]))
                return new double[]{ c1x, c1y, c2x, c2y };
        }
        return null;
    }

    private boolean curveIsClear(double x0, double y0, double x1, double y1,
                                 double x2, double y2, double x3, double y3) {
        int samples = 20;
        for (int i = 0; i <= samples; i++) {
            double t = i / (double) samples, u = 1 - t;
            double x = u*u*u*x0 + 3*u*u*t*x1 + 3*u*t*t*x2 + t*t*t*x3;
            double y = u*u*u*y0 + 3*u*u*t*y1 + 3*u*t*t*y2 + t*t*t*y3;
            if (field.blocked(x, y)) return false;
        }
        return true;
    }

    private static String fmt(double[] p) { return String.format("(%.1f, %.1f)", p[0], p[1]); }
}
