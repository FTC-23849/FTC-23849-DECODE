package org.firstinspires.ftc.teamcode.PathGen.Utilities;

import com.pedropathing.follower.Follower;
import com.pedropathing.geometry.BezierCurve;
import com.pedropathing.geometry.BezierLine;
import com.pedropathing.geometry.Pose;
import com.pedropathing.paths.PathBuilder;
import com.pedropathing.paths.PathChain;

import java.util.List;

/**
 * Thin Pedro adapter over the pure {@link PlanEngine}.
 *
 * ALL the real path logic -- routing around obstacles, keeping clearance, tangent headings so the
 * FRONT leads through each point, corner smoothing -- lives in PlanEngine, which has NO Pedro
 * dependency. This class only does the one thing that NEEDS Pedro: turn the engine's plain-data
 * segments into a Pedro PathChain. That split is deliberate: the desktop PathViz module runs the
 * exact same PlanEngine, so the visualizer can never disagree with the robot.
 *
 * The public API is unchanged: build a Field, make a PathPlanner, call plan(follower, waypoints),
 * check the PathResult before driving. Still never throws.
 */
public class PathPlanner {

    public double Vx = 76;              // forward speed in/s (fast axis)
    public double Vy = 52;             // strafe speed in/s (slow axis) -- kept for reference
    public double catmullTension = 6.0;

    private final Field field;

    public PathPlanner(Field field) { this.field = field; }

    /** Plan through waypoints (each {x, y}), start first and end last. Never throws. */
    public PathResult plan(Follower follower, List<double[]> waypoints) {
        try {
            // 1) run the pure brain -- same class the visualizer uses
            PlanEngine engine = new PlanEngine(field);
            engine.Vx = Vx;
            engine.Vy = Vy;
            engine.catmullTension = catmullTension;
            GeoResult g = engine.plan(waypoints);

            if (!g.usable())
                return PathResult.failed(g.notes.isEmpty() ? "no usable path" : g.notes.get(0));

            // 2) convert the plain-data segments into a Pedro PathChain (the only Pedro-specific step)
            PathBuilder builder = follower.pathBuilder();
            for (Seg s : g.segs) {
                Pose p1 = new Pose(s.x1, s.y1, s.h1);
                Pose p2 = new Pose(s.x2, s.y2, s.h2);
                if (s.curve) {
                    builder.addPath(new BezierCurve(p1, new Pose(s.c1x, s.c1y), new Pose(s.c2x, s.c2y), p2));
                } else {
                    builder.addPath(new BezierLine(p1, p2));
                }
                builder.setLinearHeadingInterpolation(s.h1, s.h2);
            }
            PathChain chain = builder.build();

            return g.status == GeoResult.Status.ADJUSTED
                    ? PathResult.adjusted(chain, g.notes)
                    : PathResult.ok(chain);

        } catch (Exception e) {
            return PathResult.failed("planner error: " + e.getMessage());   // never crash auto
        }
    }
}
