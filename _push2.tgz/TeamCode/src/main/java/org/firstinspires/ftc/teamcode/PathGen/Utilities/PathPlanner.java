package org.firstinspires.ftc.teamcode.PathGen.Utilities;

import com.pedropathing.follower.Follower;
import com.pedropathing.geometry.BezierCurve;
import com.pedropathing.geometry.BezierLine;
import com.pedropathing.geometry.Pose;
import com.pedropathing.paths.PathBuilder;
import com.pedropathing.paths.PathChain;

import org.firstinspires.ftc.teamcode.PathGen.core.Field;
import org.firstinspires.ftc.teamcode.PathGen.core.GeoResult;
import org.firstinspires.ftc.teamcode.PathGen.core.PlanEngine;
import org.firstinspires.ftc.teamcode.PathGen.core.Seg;

import java.util.List;

/**
 * Thin Pedro adapter over the pure PlanEngine (in the shared :PathCore module). All the path logic
 * lives in PlanEngine; this class only turns its plain-data segments into a Pedro PathChain.
 *
 *  - plan(follower, waypoints): forward pass, front leads through every point (intake).
 *  - planReturn(follower, from, to, incomingHeading): a non-intake leg (e.g. back to the scoring
 *    spot) that auto-picks forward or reverse -- whichever is faster. After the call,
 *    lastReturnReversed tells you which it chose. Blocked endpoints are nudged clear automatically.
 *
 * Never throws -- always returns a PathResult.
 */
public class PathPlanner {

    public double Vx = 76;
    public double Vy = 52;
    public double catmullTension = 6.0;
    public double turnRate = 4.0;                 // rad/s used in the forward-vs-reverse cost estimate

    /** After planReturn(...): true if it chose to drive that leg in reverse. */
    public boolean lastReturnReversed = false;

    private final Field field;

    public PathPlanner(Field field) { this.field = field; }

    private PlanEngine engine() {
        PlanEngine e = new PlanEngine(field);
        e.Vx = Vx; e.Vy = Vy; e.catmullTension = catmullTension; e.turnRate = turnRate;
        return e;
    }

    /** Forward plan through waypoints (each {x,y}), start first and end last. Never throws. */
    public PathResult plan(Follower follower, List<double[]> waypoints) {
        try {
            return toResult(follower, engine().plan(waypoints));
        } catch (Exception e) {
            return PathResult.failed("planner error: " + e.getMessage());
        }
    }

    /** Non-intake leg that auto-picks forward vs reverse. incomingHeading = the heading the robot
     *  already has arriving at `from` (reversing holds it and skips the turn). Never throws. */
    public PathResult planReturn(Follower follower, double[] from, double[] to, double incomingHeading) {
        try {
            PlanEngine e = engine();
            GeoResult g = e.planReturn(from, to, incomingHeading);
            lastReturnReversed = e.lastReturnReversed;
            return toResult(follower, g);
        } catch (Exception ex) {
            return PathResult.failed("planner error: " + ex.getMessage());
        }
    }

    /** Convert the pure segments into a Pedro PathChain (the only Pedro-specific step). */
    private PathResult toResult(Follower follower, GeoResult g) {
        if (!g.usable())
            return PathResult.failed(g.notes.isEmpty() ? "no usable path" : g.notes.get(0));

        PathBuilder builder = follower.pathBuilder();
        for (Seg s : g.segs) {
            Pose p1 = new Pose(s.x1, s.y1, s.h1);
            Pose p2 = new Pose(s.x2, s.y2, s.h2);
            if (s.curve) {
                builder.addPath(new BezierCurve(p1, new Pose(s.c1x, s.c1y), new Pose(s.c2x, s.c2y), p2));
            } else {
                builder.addPath(new BezierLine(p1, p2));
            }
            builder.setLinearHeadingInterpolation(s.h1, s.h2);
        }
        PathChain chain = builder.build();

        return g.status == GeoResult.Status.ADJUSTED
                ? PathResult.adjusted(chain, g.notes)
                : PathResult.ok(chain);
    }
}
