package org.firstinspires.ftc.teamcode.PedroAuto;

import static com.pedropathing.ivy.Scheduler.schedule;
import static com.pedropathing.ivy.commands.Commands.waitMs;
import static com.pedropathing.ivy.groups.Groups.sequential;

import com.bylazar.configurables.annotations.Configurable;
import com.pedropathing.follower.Follower;
import com.pedropathing.geometry.Pose;
import com.pedropathing.ivy.Command;
import com.pedropathing.ivy.Scheduler;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import org.firstinspires.ftc.teamcode.PathGen.Utilities.PathPlanner;
import org.firstinspires.ftc.teamcode.PathGen.Utilities.PathResult;
import org.firstinspires.ftc.teamcode.PathGen.Utilities.SafeDrive;
import org.firstinspires.ftc.teamcode.PathGen.core.Field;
import org.firstinspires.ftc.teamcode.PathGen.core.RectObstacle;
import org.firstinspires.ftc.teamcode.PathGen.core.TriObstacle;
import org.firstinspires.ftc.teamcode.PedroAuto.Subsystems.Intake;
import org.firstinspires.ftc.teamcode.PedroAuto.Subsystems.Shooter;
import org.firstinspires.ftc.teamcode.hardware.GoBildaPinpointDriver;
import org.firstinspires.ftc.teamcode.pedroPathing.Constants;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * PURE TEST for the path generator -- forever, until stopped.
 *   - starts bottom-right facing UP; intake ON + shooter (velPID + turret tracking) running (BlueAuto21 wiring)
 *   - each cycle: from the current pose, drive through 3 random ball points (front leads = intake),
 *     then RETURN to the fixed scoring spot END. The return leg auto-picks forward vs reverse --
 *     whichever is faster (straight back reverses to skip the 180 spin; a big loop drives forward).
 *   - 1s pause after each leg
 *
 * Robustness is all in the core, not this test:
 *   - PathPlanner.plan/planReturn never throw (returns OK/ADJUSTED/FAILED).
 *   - SafeDrive.follow ends on arrival OR on a real stall -> a drive can't hang.
 *   - a leg whose target is basically where we already are (< SKIP_DIST) is skipped.
 *   - a blocked target (incl. END) is nudged to the nearest clear spot -> valid at ANY heading
 *     (clearance is a bounding circle, so heading can't poke into an obstacle once the point is clear).
 *
 * Pedro coords: 144x144 in, x right, y up. Heading 0 = +x (right), 90deg = +y (up).
 */
@Configurable
@Autonomous(name = "Random Point Auto")
public class RandomPointAuto extends LinearOpMode {

    // ---- set these to your real robot ----
    private static final double ROBOT_WIDTH  = 15.5;   // inches
    private static final double ROBOT_LENGTH = 17.5;   // inches
    private static final int    PAUSE_MS     = 1000;   // pause after each leg
    private static final double SKIP_DIST    = 4.0;    // target closer than this -> already there, skip
    private static final double BALL_SPACING = 20;     // min spacing between generated ball points

    // The fixed scoring spot every cycle returns to. Orientation there doesn't matter (turret aims).
    private static final double[] END = { 48, 96 };

    // ---- shooter config (tunable in Panels, same as BlueAuto21) ----
    public static double shootingSpeedPID = -800;
    public static double turretOffset     = 0.002;
    public static double turretStartPos   = 0.5;

    // Start: bottom-right corner, facing UP. Adjust to exactly where you place the robot.
    private final Pose startPose = new Pose(135, 10, Math.toRadians(90));

    private Follower follower;
    private Intake intake;
    private Shooter shooter;
    private GoBildaPinpointDriver pinpoint;
    private Field field;
    private PathPlanner planner;
    private final Random rng = new Random();

    private boolean busy = false;
    private int pathCount = 0;
    private double[] b1, b2, b3;
    private boolean returnReversed = false;

    @Override
    public void runOpMode() {
        intake = new Intake(hardwareMap);
        shooter = new Shooter(hardwareMap, turretOffset, turretStartPos);
        pinpoint = hardwareMap.get(GoBildaPinpointDriver.class, "pinpoint");

        Scheduler.reset();
        follower = Constants.createFollower(hardwareMap);
        follower.setStartingPose(startPose);

        pinpoint.recalibrateIMU();
        sleep(1000);

        intake.init();
        shooter.init();

        // ===== obstacles (edit freely). Field is 144x144, x right, y up. =====
        field = new Field(ROBOT_WIDTH, ROBOT_LENGTH)
                .add(new RectObstacle(0, 67, 0, 144))
                .add(new TriObstacle(0, 144, 25, 144, 0, 110))
                .add(new TriObstacle(72, 96, 48, 72, 96, 72))   // diamond top half
                .add(new TriObstacle(72, 48, 48, 72, 96, 72));  // diamond bottom half
        field.minClearance(3);
        planner = new PathPlanner(field);

        telemetry.addLine("Random Point Auto -- 3 balls then return to " + fmt(END) + ", forever.");
        telemetry.addLine("Intake ON + shooter (velPID + turret) running. Return auto-reverses when faster.");
        telemetry.update();

        waitForStart();
        if (isStopRequested()) return;

        schedule(intake.intakeOn());
        schedule(shooter.startVelPID(shootingSpeedPID));
        schedule(shooter.startTurretTracking(follower));

        while (opModeIsActive()) {
            follower.update();
            Scheduler.execute();

            if (!busy && scheduleNewPath()) busy = true;

            telemetry.addData("path #", pathCount);
            telemetry.addData("state", busy ? "driving" : "planning next path");
            telemetry.addData("balls", fmt(b1) + " " + fmt(b2) + " " + fmt(b3));
            telemetry.addData("return", returnReversed ? "REVERSE" : "forward");
            telemetry.addData("intake", "ON");
            telemetry.addData("flywheel target", shootingSpeedPID);
            telemetry.addData("x", follower.getPose().getX());
            telemetry.addData("y", follower.getPose().getY());
            telemetry.addData("heading (deg)", Math.toDegrees(follower.getPose().getHeading()));
            telemetry.update();
        }
    }

    /** current -> b1 -> b2 -> b3 (forward, intake) -> END (auto forward/reverse). false if nothing drivable. */
    private boolean scheduleNewPath() {
        double[] cur = { follower.getPose().getX(), follower.getPose().getY() };
        b1 = randomValidPoint(cur, BALL_SPACING);
        b2 = randomValidPoint(b1,  BALL_SPACING);
        b3 = randomValidPoint(b2,  BALL_SPACING);

        // intake legs: front leads through each ball
        PathResult leg1 = planner.plan(follower, points(cur, b1));
        PathResult leg2 = planner.plan(follower, points(b1,  b2));
        PathResult leg3 = planner.plan(follower, points(b2,  b3));

        // return leg: auto forward/reverse. incoming heading = how we arrived at b3 (facing from b2).
        double inHeading = Math.atan2(b3[1] - b2[1], b3[0] - b2[0]);
        PathResult ret = planner.planReturn(follower, b3, END, inHeading);
        returnReversed = planner.lastReturnReversed;

        List<Command> steps = new ArrayList<>();
        addLeg(steps, cur, b1, leg1);
        addLeg(steps, b1,  b2, leg2);
        addLeg(steps, b2,  b3, leg3);
        addLeg(steps, b3,  END, ret);
        if (steps.isEmpty()) return false;

        steps.add(Command.build().setStart(() -> busy = false).setDone(() -> true));
        schedule(sequential(steps.toArray(new Command[0])));
        pathCount++;
        return true;
    }

    /** Add a leg's drive + pause, only if it planned AND the target isn't basically where we are. */
    private void addLeg(List<Command> steps, double[] from, double[] to, PathResult leg) {
        if (leg == null || !leg.usable()) return;
        if (dist(from, to) < SKIP_DIST) return;
        steps.add(SafeDrive.follow(follower, leg.path));
        steps.add(waitMs(PAUSE_MS));
    }

    private static List<double[]> points(double[] a, double[] b) {
        List<double[]> list = new ArrayList<>();
        list.add(a);
        list.add(b);
        return list;
    }

    /** Random point inside the field, not inside any obstacle, at least minAway inches from `from`. */
    private double[] randomValidPoint(double[] from, double minAway) {
        double inset = field.robotRadius + 4;
        double lo = inset, hi = 144 - inset;
        double[] best = { (lo + hi) / 2, (lo + hi) / 2 };
        for (int i = 0; i < 300; i++) {
            double x = lo + rng.nextDouble() * (hi - lo);
            double y = lo + rng.nextDouble() * (hi - lo);
            if (field.blocked(x, y)) continue;
            best = new double[]{ x, y };
            if (dist(best, from) >= minAway) return best;
        }
        return best;
    }

    private static double dist(double[] a, double[] b) { return Math.hypot(a[0] - b[0], a[1] - b[1]); }
    private static String fmt(double[] p) { return p == null ? "-" : String.format("(%.0f,%.0f)", p[0], p[1]); }
}
